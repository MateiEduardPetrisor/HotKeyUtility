﻿using System;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace VolumeAndBrightnessHotKey
{
    public partial class HiddenForm : Form
    {
        [DllImport("user32.dll")]
        private static extern bool RegisterHotKey(IntPtr hWnd, int id, int fsModifiers, int vk);
        [DllImport("user32.dll")]
        private static extern bool UnregisterHotKey(IntPtr hWnd, int id);
        private VolumeUtils VolumeUtilsObj;
        private BrightnessUtils BrightnessUtilsObj;

        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams CreateParamsObj = base.CreateParams;
                CreateParamsObj.ExStyle |= 0x80;
                return CreateParamsObj;
            }
        }

        protected override void WndProc(ref Message MessageObjct)
        {
            base.WndProc(ref MessageObjct);

            if (MessageObjct.Msg == 0x0312)
            {
                int HotKeyId = MessageObjct.WParam.ToInt32();
                switch (HotKeyId)
                {
                    case (int)HotKeyIds.IncreaseVolumeHotKeyId:
                        this.VolumeUtilsObj.IncreaseSoundLevel();
                        break;
                    case (int)HotKeyIds.DecreaseVolumeHotKeyId:
                        this.VolumeUtilsObj.DecreaseSoundLevel();
                        break;
                    case (int)HotKeyIds.MuteVolumeHotKeyId:
                        this.VolumeUtilsObj.MuteSound();
                        break;
                    case (int)HotKeyIds.ReaquireAudioDeviceHotKeyId:
                        this.VolumeUtilsObj.ResetCoreAudioDevice();
                        break;
                    case (int)HotKeyIds.IncreaseBrigthnessHotKeyId:
                        this.BrightnessUtilsObj.IncreaseBrightness();
                        break;
                    case (int)HotKeyIds.DecreaseBrigthnessHotKeyId:
                        this.BrightnessUtilsObj.DecreaseBrightness();
                        break;
                    case (int)HotKeyIds.ExitApplicationHotKeyId:
                        this.Close();
                        break;
                }
            }
        }

        public HiddenForm()
        {
            InitializeComponent();
            this.VolumeUtilsObj = new VolumeUtils();
            this.BrightnessUtilsObj = new BrightnessUtils();
        }

        private void HiddenForm_Load(object sender, EventArgs e)
        {
            RegisterHotKey(this.Handle, (int)HotKeyIds.DecreaseVolumeHotKeyId, (int)KeyModifier.WinKey, Keys.F5.GetHashCode());
            RegisterHotKey(this.Handle, (int)HotKeyIds.IncreaseVolumeHotKeyId, (int)KeyModifier.WinKey, Keys.F6.GetHashCode());
            RegisterHotKey(this.Handle, (int)HotKeyIds.MuteVolumeHotKeyId, (int)KeyModifier.WinKey, Keys.F7.GetHashCode());
            RegisterHotKey(this.Handle, (int)HotKeyIds.ReaquireAudioDeviceHotKeyId, (int)KeyModifier.WinKey, Keys.F8.GetHashCode());
            RegisterHotKey(this.Handle, (int)HotKeyIds.DecreaseBrigthnessHotKeyId, (int)KeyModifier.WinKey, Keys.F9.GetHashCode());
            RegisterHotKey(this.Handle, (int)HotKeyIds.IncreaseBrigthnessHotKeyId, (int)KeyModifier.WinKey, Keys.F10.GetHashCode());
            RegisterHotKey(this.Handle, (int)HotKeyIds.ExitApplicationHotKeyId, (int)KeyModifier.WinKey, Keys.End.GetHashCode());
        }

        private void HiddenForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.VolumeUtilsObj.Dispose();
            UnregisterHotKey(this.Handle, (int)HotKeyIds.DecreaseVolumeHotKeyId);
            UnregisterHotKey(this.Handle, (int)HotKeyIds.IncreaseVolumeHotKeyId);
            UnregisterHotKey(this.Handle, (int)HotKeyIds.MuteVolumeHotKeyId);
            UnregisterHotKey(this.Handle, (int)HotKeyIds.ReaquireAudioDeviceHotKeyId);
            UnregisterHotKey(this.Handle, (int)HotKeyIds.DecreaseBrigthnessHotKeyId);
            UnregisterHotKey(this.Handle, (int)HotKeyIds.IncreaseBrigthnessHotKeyId);
            UnregisterHotKey(this.Handle, (int)HotKeyIds.ExitApplicationHotKeyId);
        }
    }
}