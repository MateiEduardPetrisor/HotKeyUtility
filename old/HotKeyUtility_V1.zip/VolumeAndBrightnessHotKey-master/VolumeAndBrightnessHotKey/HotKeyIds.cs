﻿namespace VolumeAndBrightnessHotKey
{
    public enum HotKeyIds
    {
        IncreaseVolumeHotKeyId = 5313,
        DecreaseVolumeHotKeyId = 5314,
        MuteVolumeHotKeyId = 5315,
        ReaquireAudioDeviceHotKeyId = 5316,
        ExitApplicationHotKeyId = 5317,
        IncreaseBrigthnessHotKeyId = 5318,
        DecreaseBrigthnessHotKeyId = 5319
    }
}