# VolumeAndBrightnessHotKey

An application for adjusting system volume and screen brightness on windows.
The application requires .Net Framework v4+.
 - Winkey + F5 Decrease volume;
 - Winkey + F6 Increase volume;
 - Winkey + F7 Mute volume;
 - Winkey + F8 Reaquire default playback device(use this if you change playback device in control panel);
 - Winkey + F9 Decrease screen brigthness;
 - Winkey + F10 Increase screen brigthness;
 - Winkey + End Exit application.