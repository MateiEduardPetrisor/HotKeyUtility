﻿Winkey + F5 Decrease volume
Winkey + F6 Increase volume
Winkey + F7 Mute volume
Winkey + F8 Lower screen brigthness
Winkey + F9 Increase screen brigthness
Winkey + F10 Disable network adapters
Winkey + F11 Enable network adapters
Winkey + End Exit application
