﻿namespace HotkeyUtility
{
    public enum HotKeyIds
    {
        IncreaseVolumeHotKeyId = 5313,
        DecreaseVolumeHotKeyId = 5314,
        MuteVolumeHotKeyId = 5315,
        ExitApplicationHotKeyId = 5316,
        IncreaseBrigthnessHotKeyId = 5317,
        DecreaseBrigthnessHotKeyId = 5318,
        DisableNetworkConnection = 5319,
        EnableNetworkConnection = 5320,
    }
}