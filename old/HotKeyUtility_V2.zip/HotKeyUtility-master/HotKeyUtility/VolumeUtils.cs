﻿using AudioSwitcher.AudioApi.CoreAudio;
using System;

namespace HotkeyUtility
{
    public class VolumeUtils : IDisposable
    {
        private CoreAudioController CoreAudioControllerObj;
        private CoreAudioDevice CoreAudioDeviceObj;
        private readonly double VolumeChangeValue;

        public VolumeUtils()
        {
            this.CoreAudioControllerObj = new CoreAudioController();
            this.CoreAudioDeviceObj = this.CoreAudioControllerObj.DefaultPlaybackDevice;
            this.VolumeChangeValue = 2;
        }

        public void IncreaseSoundLevel()
        {
            this.CoreAudioDeviceObj = this.CoreAudioControllerObj.DefaultPlaybackDevice;
            double VolumeValue = this.CoreAudioDeviceObj.Volume + this.VolumeChangeValue;
            if (VolumeValue >= 100)
            {
                this.CoreAudioDeviceObj.Volume = 100;
            }
            else
            {
                this.CoreAudioDeviceObj.Volume = VolumeValue;
            }
        }

        public void DecreaseSoundLevel()
        {
            this.CoreAudioDeviceObj = this.CoreAudioControllerObj.DefaultPlaybackDevice;
            double VolumeValue = this.CoreAudioDeviceObj.Volume - this.VolumeChangeValue;
            if (VolumeValue <= 0)
            {
                this.CoreAudioDeviceObj.Volume = 0;
            }
            else
            {
                this.CoreAudioDeviceObj.Volume = VolumeValue;
            }
        }

        public void MuteSound()
        {
            this.CoreAudioDeviceObj = this.CoreAudioControllerObj.DefaultPlaybackDevice;
            if (this.CoreAudioDeviceObj.IsMuted)
            {
                this.CoreAudioDeviceObj.ToggleMute();
            }
            else
            {
                this.CoreAudioDeviceObj.ToggleMute();
            }
        }

        public void Dispose()
        {
            this.CoreAudioControllerObj.Dispose();
            this.CoreAudioDeviceObj.Dispose();
        }
    }
}